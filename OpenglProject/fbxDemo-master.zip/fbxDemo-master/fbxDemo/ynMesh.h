#pragma once
#include <vector>
#include <string>

#include "glm/vec2.hpp"
#include "glm/vec3.hpp"

#include "GL/glew.h"
#include "GL/freeglut.h"

namespace CYN
{
	struct Vertex
	{
		glm::vec3 position;
		glm::vec3 normal;
		glm::vec3 texCoord;
	};
	struct Texture
	{
		GLuint id;
		GLuint type;
		std::string path;
	};
	class Mesh
	{
	public:
		void initOpenGL();
		void draw();
	public:
		std::vector<Vertex> m_vVertices;
		std::vector<Texture> m_vTextures;
		std::vector<unsigned> m_vIndices;
		Mesh(const std::vector<Vertex> & i_verticesData, const std::vector<Texture> & i_texData);
		Mesh(const std::vector<Vertex> & i_verticesData, const std::vector<Texture> & i_texData, const std::vector<unsigned> & i_indices);
		~Mesh();
	public:
		inline GLuint getVAO() const { return m_gliVao; }
	private:
		GLuint m_gliVao, m_gliVbo, m_gliNbo, m_gliUvbo;
		GLuint m_gliIndiceBuffer;
	};
}
